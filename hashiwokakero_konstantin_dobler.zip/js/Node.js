"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Node = /** @class */ (function () {
    function Node(row, col, neededEdges) {
        this.row = row;
        this.col = col;
        this.neededEdges = neededEdges;
        this.edgeCount = 0;
        this.row = row;
        this.col = col;
        this.neededEdges = neededEdges;
    }
    return Node;
}());
exports.default = Node;
//# sourceMappingURL=Node.js.map